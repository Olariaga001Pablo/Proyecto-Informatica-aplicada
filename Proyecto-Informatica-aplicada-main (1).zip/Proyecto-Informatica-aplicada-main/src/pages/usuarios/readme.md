# Módulo Usuarios

Este directorio contiene los archivos relacionados con la gestión de usuarios en el proyecto.

## Archivos actuales

- `script.js`: Controlador para manejar las solicitudes relacionadas con usuarios.

- `readme.md`: Documentación del módulo de usuarios.

## Funcionalidades

- Registro de usuarios
- Consulta de información de usuario

