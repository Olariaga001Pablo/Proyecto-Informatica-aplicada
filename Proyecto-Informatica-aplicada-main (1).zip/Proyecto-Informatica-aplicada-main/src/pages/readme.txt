
README - Carpeta pages
======================

Esta carpeta contiene archivos de prueba para la interfaz de usuario de la aplicación.

Propósito:
----------
- Los archivos aquí presentes son solo pruebas de diseño y funcionalidad.
- El contenido y la estructura están sujetos a cambios y serán modificados en futuras versiones del proyecto.

Notas:
------
- No se recomienda tomar como referencia definitiva el código de esta carpeta.
- Próximamente se actualizarán los archivos para adaptarse a los requerimientos finales de la aplicación.
