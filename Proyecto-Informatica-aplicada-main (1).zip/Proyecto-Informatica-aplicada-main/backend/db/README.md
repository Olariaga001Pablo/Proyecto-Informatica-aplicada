Crear la Base de Datos

⚠️ No subir paneles.db al repositorio: cada quien debe generar su propia base para evitar conflictos y archivos pesados.

cd Proyecto-Informatica-aplicada/backend/db
sqlite3 Paneles.db < DB_Paneles.sql